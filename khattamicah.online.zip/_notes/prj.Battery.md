---
title: "Battery - meanings through time and onward"
tags: Bank reframe prompt
toc: true
season: spring
---

<iframe src="http://www.finedictionary.com/battery.html" width="800" height="400" class="resize-vertical"></iframe>
## Initial  Clues
Leyden Jars
Military Equipment
Rams and batteries were the same?
Crime(?)

## thoughts
- ==it seems to be a group of somethings designed to do somefunctions. ==
	- The only exception seems to be the crime of battery. 
		- Legal definitions of battery -through history- might be interesting to look at
- Is this where Bat is cricket and baseball come from?
	- but in baseball battery = catcher and pitcher
- Naming system of the electric battery seems to be based on structure?
- 1.  BRITISH
    
    a series of small cages for the intensive rearing of farm animals, especially calves and poultry.
    
    "battery farming"
		- ==this seems to be the most apt metaphor for modern day batteries. a process of intensive repititive exploitation and depletion. at scale. ==

## Related?
<iframe src="https://www.merriam-webster.com/dictionary/batter#:~:text=intransitive%20verb,electric-light%20bulbs—%20D.%20B.%20Chidsey" class="resize-vertical" width="800" height="400"></iframe>

with this definition a more full definition arises - **a repititive group of somethings/someactions designed to do someactions or someeffect - usually related to striking or building capacity to strike**

==Can the reframing be about cycles of filling and depleting? Like reservoirs?==