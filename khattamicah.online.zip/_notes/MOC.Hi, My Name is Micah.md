---
title: "My Portfolio and My Statement"
tags: Portfolio MOC
toc: false
season: summer
---
I might be a designer. Or a researcher? or something else. 

I hold on to different interests like #music, #movies, #videoessays, #linguisticidiosyncracies, #psychology, #philosophies, #fantasy, #science-fiction and many more. I would like to find a career that helps me borrow from all these places.

>My dream is to be a great generalist, who keeps a team together, navigates complex situations and co-creates and co-realizes visions for an equitable and sustainable future.

This is list of projects I have worked on
- [[prj.Designer’s Ace]]
- [[prj.Speculative Storytelling]]
- [[prj.Carpooling Unalone - Karwaan]]
- [[prj.Making Visible something in an RO plant - Water Quality]]
- [My Art](/art/)