---
title: Technological Terms and their Metaphors
tags: list reframe language
toc: false
season: winter
---
* Bug
* Screen
* [[prj.Battery]]
* Charge-ing (re-)
* Code
* 
