---
title: Capstone Extending 
tags: Internal
toc: false
season: autumn
---


# Thoughts about the Capstone

## Does it need to fit into a particular domain
	* Would domainifying this lead to its remediation
	* [[Compost Thoughts]] - remdiation in context 1
	* infrastructuring as meme - remediation in context 2	
## Paul's thoughts - "The archetypes work well because they can be plugged into different communities. a maintainer in one field looks very differernt in another"


## Archive
the first draft is hard to get out and I follow one of two approaches, gardening or planning or some hybrid. 
The writing process started off with a simple outline which I then followed with a graphic illustration of each of the section. This helped me sort out my metaphors and make a much more expanded outline. 
After talking to shreyas, I decided to strucure it the way that I would, without academic boundaries. Is there a translation possible between the two?
Even then my outline is now based the questions, and that allows for a little bit of Non-Linear Storytelling

[[moc.Narratives]]