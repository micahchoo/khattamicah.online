---
title: Sahitya Akademi 1992 Seminar Transcripts
tags: Bank
toc: true
season: winter
---


* Jonathan Culler - If reality and social groups are constructed by narrative, deconstruction and reorganisation to resist while admiring the lure of nationalistic narratives gaining dangerous influence
	* Side: https://www.instagram.com/p/CIP4LByJLYN/?igshid=uvwdgt2kc26z
* Harbajan Singh - Literary tradition is right now elemental without being integrative. Western lenses for looking at narratives cannot be used to construct Indian Literary Traditions. 
* Earl Milner - Derrida "archaeology of silences" - tree falls in the forest. Asian Literary traditions offer different ways of handling the Narrative. These ways differ in time, form and expression. The silence in western circles is deafening.
* 