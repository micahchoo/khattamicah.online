---
title: Names of different Literary Forms from Asia
tags: List 
toc: true
season: autumn
---



# Names of different Literary Forms from Asia
* Shosetsu - Japanese Novel
* Classical Chinese Novel - 120 shortish chapters [Hsia-shuo](https://www.jstor.org/stable/10.7312/hsia12990)
*