---
title: Alternative Narrative Systems
tags: List 
toc: true
season: winter
---

# Narrative Systems
* [Affective-Expressive Systems](https://www.jstor.org/stable/1343001)
		* Seed: 
						* #Read 
							* [[Bank.Tale of Genji]] - Narrative Systems are unique
								* #ReadAlt 
									* [Tale of Genji Audiobook](https://www.youtube.com/watch?v=NR58kLrp88o)
									* Manga - Dreams at Dawn (Asaki yumemishi) by Yamato Waki
* [Magical Realism](https://www.researchgate.net/publication/345158288_Magical_Realism_in_Gabriel_Garcia_Marquez%27_s_One_Hundred_Years_Of_Solitude)





