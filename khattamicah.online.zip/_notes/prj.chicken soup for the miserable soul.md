---
title: Suffernama - My Newsletter
tags: Project
toc: true
season: spring
---

>when the tough gets going, we get going. or something.

[ In this newsletter](https://suffernama.substack.com) I share music, videos, technology, poems, puns - basically anything that brings me joy. you will see me laugh and cry here. 

 #writing 
 [[MOC.Hi, My Name is Micah]]