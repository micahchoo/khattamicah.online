---
title: Coauthoring and Spatialising Representations of Events and Thoughts 
tags: Internal SpatialThoughts CoAuthoring
toc: true
season: autumn
---

* Is compost a way of putting [[int.Thoughts about the Capstone]] into context
	* The co-authoring bit comes from archetypes of care
	* Archetypes come from the roles that people have played in collectives
	* Does this come closer to co-authoring as the only way a collective puts things out there?
		* what about the non-humans? Where do they feature
	* Paul's thoughts - "The archetypes work well because they can be plugged into different communities. a maintainer in one field looks very differernt in another"


tags