---
layout: post
title: Art	
permalink: /art/
content-type: eg
toc: true
---

# Poems
<a data-flickr-embed="true" href="https://www.flickr.com/photos/192463991@N08/albums/72157718568108987" title="Poems"><img src="https://live.staticflickr.com/65535/51015247587_17c33cffcb_b.jpg" width="100%" height="auto" alt="Poems"></a><script async src="//embedr.flickr.com/assets/client-code.js" charset="utf-8"></script>

# Protest
<a data-flickr-embed="true" href="https://www.flickr.com/photos/192463991@N08/albums/72157718565671308" title="Protest Glitch Art"><img src="https://live.staticflickr.com/65535/51015246827_16a9075490_h.jpg" width="100%" height="auto" alt="Protest Glitch Art"></a><script async src="//embedr.flickr.com/assets/client-code.js" charset="utf-8"></script>

# Paintings 
<a data-flickr-embed="true" href="https://www.flickr.com/photos/192463991@N08/albums/72157718557164141" title="Digital Paintings"><img src="https://live.staticflickr.com/65535/51013520122_40bef1b6cf_h.jpg" width="100%" height="auto" alt="Digital Paintings"></a><script async src="//embedr.flickr.com/assets/client-code.js" charset="utf-8"></script>
